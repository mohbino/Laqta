package com.laqta.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.laqta.app.data.MockDataProvider
import com.laqta.app.model.Product
import com.laqta.app.ui.screens.*
import com.laqta.app.ui.theme.AmberAccent
import com.laqta.app.ui.theme.LaqtaTheme
import com.laqta.app.ui.theme.NavyPrimary
import com.laqta.app.ui.theme.NavySurface
import com.laqta.app.ui.theme.TextPrimary
import com.laqta.app.ui.theme.TextSecondary

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LaqtaTheme {
                MainAppScreen()
            }
        }
    }
}

enum class Screen {
    HOME, SEARCH, FAVORITES, SETTINGS, PRODUCT_DETAIL
}

@Composable
fun MainAppScreen() {
    var currentScreen by remember { mutableStateOf(Screen.HOME) }
    var selectedProduct by remember { mutableStateOf<Product?>(null) }
    var selectedCategoryForSearch by remember { mutableStateOf<String?>(null) }
    var favoritesIds by remember { mutableStateOf(setOf<String>()) }

    val allProducts = MockDataProvider.products
    val favoriteProducts = remember(favoritesIds) {
        allProducts.filter { it.id in favoritesIds }
    }

    Scaffold(
        containerColor = NavyPrimary,
        bottomBar = {
            if (currentScreen != Screen.PRODUCT_DETAIL) {
                NavigationBar(
                    containerColor = NavySurface
                ) {
                    NavigationBarItem(
                        selected = currentScreen == Screen.HOME,
                        onClick = { currentScreen = Screen.HOME },
                        icon = { Icon(Icons.Default.Home, contentDescription = "الرئيسية") },
                        label = { Text("الرئيسية") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AmberAccent,
                            selectedTextColor = AmberAccent,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary,
                            indicatorColor = NavyPrimary
                        )
                    )
                    NavigationBarItem(
                        selected = currentScreen == Screen.SEARCH,
                        onClick = {
                            selectedCategoryForSearch = null
                            currentScreen = Screen.SEARCH
                        },
                        icon = { Icon(Icons.Default.Search, contentDescription = "البحث") },
                        label = { Text("البحث") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AmberAccent,
                            selectedTextColor = AmberAccent,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary,
                            indicatorColor = NavyPrimary
                        )
                    )
                    NavigationBarItem(
                        selected = currentScreen == Screen.FAVORITES,
                        onClick = { currentScreen = Screen.FAVORITES },
                        icon = { Icon(Icons.Default.Favorite, contentDescription = "المفضلة") },
                        label = { Text("المفضلة") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AmberAccent,
                            selectedTextColor = AmberAccent,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary,
                            indicatorColor = NavyPrimary
                        )
                    )
                    NavigationBarItem(
                        selected = currentScreen == Screen.SETTINGS,
                        onClick = { currentScreen = Screen.SETTINGS },
                        icon = { Icon(Icons.Default.Settings, contentDescription = "الإعدادات") },
                        label = { Text("الإعدادات") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AmberAccent,
                            selectedTextColor = AmberAccent,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary,
                            indicatorColor = NavyPrimary
                        )
                    )
                }
            }
        }
    ) { paddingValues ->
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            color = NavyPrimary
        ) {
            when (currentScreen) {
                Screen.HOME -> HomeScreen(
                    onProductClick = {
                        selectedProduct = it
                        currentScreen = Screen.PRODUCT_DETAIL
                    },
                    onCategoryClick = { catId ->
                        selectedCategoryForSearch = catId
                        currentScreen = Screen.SEARCH
                    },
                    onSearchClick = {
                        selectedCategoryForSearch = null
                        currentScreen = Screen.SEARCH
                    }
                )
                Screen.SEARCH -> SearchScreen(
                    initialCategory = selectedCategoryForSearch,
                    onProductClick = {
                        selectedProduct = it
                        currentScreen = Screen.PRODUCT_DETAIL
                    }
                )
                Screen.FAVORITES -> FavoritesScreen(
                    favoriteProducts = favoriteProducts,
                    onProductClick = {
                        selectedProduct = it
                        currentScreen = Screen.PRODUCT_DETAIL
                    },
                    onExploreClick = {
                        currentScreen = Screen.HOME
                    }
                )
                Screen.SETTINGS -> SettingsScreen()
                Screen.PRODUCT_DETAIL -> {
                    selectedProduct?.let { prod ->
                        val isFav = prod.id in favoritesIds
                        ProductDetailScreen(
                            product = prod,
                            isFavorite = isFav,
                            onToggleFavorite = {
                                favoritesIds = if (isFav) {
                                    favoritesIds - prod.id
                                } else {
                                    favoritesIds + prod.id
                                }
                            },
                            onBack = {
                                currentScreen = Screen.HOME
                            }
                        )
                    }
                }
            }
        }
    }
}
