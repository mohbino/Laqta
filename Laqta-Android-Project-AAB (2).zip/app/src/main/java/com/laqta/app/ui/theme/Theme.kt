package com.laqta.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = AmberAccent,
    secondary = AmberGold,
    background = NavyPrimary,
    surface = NavySurface,
    onPrimary = NavyPrimary,
    onSecondary = NavyPrimary,
    onBackground = TextPrimary,
    onSurface = TextPrimary
)

@Composable
fun LaqtaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
