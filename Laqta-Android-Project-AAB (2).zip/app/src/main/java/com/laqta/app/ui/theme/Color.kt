package com.laqta.app.ui.theme

import androidx.compose.ui.graphics.Color

val NavyPrimary = Color(0xFF0F172A)
val NavySurface = Color(0xFF1E293B)
val AmberAccent = Color(0xFFF59E0B)
val AmberGold = Color(0xFFD97706)
val EmeraldDeal = Color(0xFF10B981)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val BorderDark = Color(0xFF334155)
