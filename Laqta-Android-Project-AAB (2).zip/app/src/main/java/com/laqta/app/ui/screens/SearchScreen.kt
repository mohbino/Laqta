package com.laqta.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.laqta.app.data.MockDataProvider
import com.laqta.app.model.Product
import com.laqta.app.ui.theme.AmberAccent
import com.laqta.app.ui.theme.NavyPrimary
import com.laqta.app.ui.theme.NavySurface
import com.laqta.app.ui.theme.TextPrimary

@Composable
fun SearchScreen(
    initialCategory: String? = null,
    onProductClick: (Product) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(initialCategory ?: "all") }

    val filteredProducts = remember(searchQuery, selectedCategory) {
        MockDataProvider.products.filter { product ->
            val matchQuery = searchQuery.isBlank() ||
                    product.nameAr.contains(searchQuery, ignoreCase = true) ||
                    product.nameEn.contains(searchQuery, ignoreCase = true) ||
                    product.storeName.contains(searchQuery, ignoreCase = true)

            val matchCategory = selectedCategory == "all" || product.categoryId == selectedCategory

            matchQuery && matchCategory
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyPrimary)
            .padding(16.dp)
    ) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("ابحث بالعربية أو الإنجليزية...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = AmberAccent) },
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = NavySurface,
                unfocusedContainerColor = NavySurface,
                focusedBorderColor = AmberAccent,
                unfocusedBorderColor = NavySurface,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "النتائج (${filteredProducts.size})",
            color = TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 96.dp)
        ) {
            items(filteredProducts) { product ->
                ProductRowItem(product = product, onClick = { onProductClick(product) })
            }
        }
    }
}
