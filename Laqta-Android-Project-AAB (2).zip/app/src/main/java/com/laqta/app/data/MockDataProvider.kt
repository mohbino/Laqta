package com.laqta.app.data

import com.laqta.app.model.Category
import com.laqta.app.model.Product
import com.laqta.app.model.StoreComparison

object MockDataProvider {
    val categories = listOf(
        Category("all", "الكل", "All", "grid"),
        Category("electronics", "إلكترونيات", "Electronics", "tv"),
        Category("mobiles", "موبايلات", "Mobiles", "phone"),
        Category("computers", "كمبيوتر", "Computers", "laptop"),
        Category("clothing", "ملابس", "Clothing", "shirt"),
        Category("shoes", "أحذية", "Shoes", "shoes"),
        Category("home", "منزل", "Home", "home"),
        Category("restaurants", "مطاعم", "Restaurants", "food"),
        Category("supermarket", "سوبرماركت", "Supermarket", "cart"),
        Category("other", "أخرى", "Other", "more")
    )

    val jordanCities = listOf("الكل", "عمان", "إربد", "الزرقاء", "العقبة", "السلط")

    val jordanStores = listOf(
        "الكل",
        "ليدرز سنتر (Leaders)",
        "سمارت باي (SmartBuy)",
        "كارفور الأردن (Carrefour)",
        "كوزمو (Cozmo)",
        "سيتي سنتر (City Center)",
        "دي إن إيه (DNA)",
        "سامح مول (Sameh Mall)",
        "مايلز سوبرماركت (Miles)",
        "فيرجن ميجاستور (Virgin)"
    )

    val products = listOf(
        Product(
            id = "prod-1",
            nameAr = "آبل آيفون 15 برو ماكس 256 جيجابايت - تيتانيوم",
            nameEn = "Apple iPhone 15 Pro Max 256GB Natural Titanium",
            descriptionAr = "هاتف ذكي بشريحة A17 Pro مع كاميرا احترافية بدقة 48 ميجابكسل، هيكل من التيتانيوم القوي، ومنفذ Type-C فائق السرعة.",
            categoryId = "mobiles",
            price = 889.0,
            oldPrice = 1049.0,
            discountPercentage = 15,
            storeName = "ليدرز سنتر (Leaders)",
            city = "عمان",
            storePhone = "+96265333332",
            storeWhatsapp = "+962799991234",
            imageUrl = "https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800",
            isLatestDeal = true,
            viewsCount = 1420,
            updatedAt = "اليوم",
            otherStores = listOf(
                StoreComparison("سمارت باي (SmartBuy)", 915.0, 1049.0, "عمان", true, "أمس"),
                StoreComparison("دي إن إيه (DNA)", 899.0, 1020.0, "عمان", true, "اليوم")
            )
        ),
        Product(
            id = "prod-2",
            nameAr = "سامسونج تلفزيون 65 بوصة 4K UHD Crystal الذكي",
            nameEn = "Samsung 65 Inch 4K UHD Crystal Smart TV",
            descriptionAr = "شاشة سينمائية فائقة الوضوح مع معالج Crystal 4K، دعم تقنية HDR10+، ونظام تشغيل Tizen.",
            categoryId = "electronics",
            price = 369.0,
            oldPrice = 480.0,
            discountPercentage = 23,
            storeName = "سمارت باي (SmartBuy)",
            city = "عمان",
            imageUrl = "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=800",
            isLatestDeal = true,
            viewsCount = 2350,
            updatedAt = "اليوم",
            otherStores = listOf(
                StoreComparison("ليدرز سنتر (Leaders)", 385.0, 499.0, "إربد", true, "اليوم"),
                StoreComparison("كارفور الأردن (Carrefour)", 379.0, 470.0, "الزرقاء", true, "أمس")
            )
        ),
        Product(
            id = "prod-3",
            nameAr = "سماعات سوني اللاسلكية WH-1000XM5 مانعة للضوضاء",
            nameEn = "Sony WH-1000XM5 Wireless Noise Cancelling Headphones",
            descriptionAr = "أفضل تقنية عزل ضوضاء في العالم مع 8 ميكروفونات وبطارية تدوم حتى 30 ساعة.",
            categoryId = "electronics",
            price = 245.0,
            oldPrice = 320.0,
            discountPercentage = 23,
            storeName = "دي إن إيه (DNA)",
            city = "عمان",
            imageUrl = "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800",
            isLatestDeal = true,
            viewsCount = 1890,
            updatedAt = "أمس"
        ),
        Product(
            id = "prod-4",
            nameAr = "لابتوب ديل للألعاب Dell G15 مع RTX 4060",
            nameEn = "Dell G15 Gaming Laptop Intel Core i7 RTX 4060",
            descriptionAr = "أداء ألعاب استثنائي مع معالج الجيل 13 وذاكرة 16GB وشاشة 165Hz.",
            categoryId = "computers",
            price = 799.0,
            oldPrice = 950.0,
            discountPercentage = 16,
            storeName = "سيتي سنتر (City Center)",
            city = "عمان",
            imageUrl = "https://images.unsplash.com/photo-1603302576837-37561b2e2302?w=800",
            viewsCount = 980,
            updatedAt = "اليوم"
        ),
        Product(
            id = "prod-5",
            nameAr = "قلاية هوائية فيليبس XXL سعة 7.3 لتر بريميوم",
            nameEn = "Philips Airfryer XXL 7.3L Premium",
            descriptionAr = "طهي صحي بدهون أقل حتى 90% بتقنية Rapid Air وشاشة لمس رقمية.",
            categoryId = "home",
            price = 179.0,
            oldPrice = 240.0,
            discountPercentage = 25,
            storeName = "سمارت باي (SmartBuy)",
            city = "عمان",
            imageUrl = "https://images.unsplash.com/photo-1585515320310-259814833e62?w=800",
            isLatestDeal = true,
            viewsCount = 2150,
            updatedAt = "أمس"
        ),
        Product(
            id = "prod-6",
            nameAr = "حذاء نايكي إير ماكس 270 الرياضي",
            nameEn = "Nike Air Max 270 Men Running Shoes",
            descriptionAr = "تصميم رياضي مريح مع وحدة هواء ناعمة تدوم طوال اليوم.",
            categoryId = "shoes",
            price = 79.0,
            oldPrice = 115.0,
            discountPercentage = 31,
            storeName = "نايكي الأردن (Nike Jordan)",
            city = "عمان",
            imageUrl = "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800",
            isLatestDeal = true,
            viewsCount = 4120,
            updatedAt = "اليوم"
        ),
        Product(
            id = "prod-7",
            nameAr = "زيت زيتون بلدي نخب أول عجلوني تنكة 16 لتر",
            nameEn = "Ajloun Extra Virgin Olive Oil 16L",
            descriptionAr = "زيت زيتون أردني أصلي معصور على البارد من جبال عجلون.",
            categoryId = "supermarket",
            price = 85.0,
            oldPrice = 105.0,
            discountPercentage = 19,
            storeName = "سامح مول (Sameh Mall)",
            city = "الزرقاء",
            imageUrl = "https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=800",
            viewsCount = 3890,
            updatedAt = "اليوم"
        ),
        Product(
            id = "prod-8",
            nameAr = "أرز صنوايت كالروز الأسترالي 10 كغم",
            nameEn = "Sunwhite Calrose Rice 10kg",
            descriptionAr = "أرز الحبة المتوسطة الفاخر ذو الجودة العالية في الأردن.",
            categoryId = "supermarket",
            price = 11.75,
            oldPrice = 14.50,
            discountPercentage = 19,
            storeName = "كارفور الأردن (Carrefour)",
            city = "عمان",
            imageUrl = "https://images.unsplash.com/photo-1586201375761-83865001e31c?w=800",
            isLatestDeal = true,
            viewsCount = 5200,
            updatedAt = "اليوم"
        )
    )
}
