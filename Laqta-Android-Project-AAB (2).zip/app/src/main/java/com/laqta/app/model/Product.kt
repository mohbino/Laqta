package com.laqta.app.model

data class Category(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val iconName: String
)

data class StoreComparison(
    val storeName: String,
    val price: Double,
    val oldPrice: Double? = null,
    val city: String,
    val inStock: Boolean = true,
    val updatedAt: String
)

data class Product(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val descriptionAr: String,
    val categoryId: String,
    val price: Double, // in JOD
    val oldPrice: Double? = null,
    val discountPercentage: Int? = null,
    val storeName: String,
    val city: String,
    val storePhone: String? = null,
    val storeWhatsapp: String? = null,
    val storeWebsite: String? = null,
    val imageUrl: String,
    val isLatestDeal: Boolean = false,
    val viewsCount: Int = 0,
    val updatedAt: String,
    val otherStores: List<StoreComparison> = emptyList()
)
