# Proguard rules for Laqta App
# Add project specific ProGuard rules here.
# By default, the flags in this file are appended to flags specified
# in /path/to/sdk/tools/proguard/proguard-android-optimize.txt

# Keep Jetpack Compose & Kotlin reflection safe
-keepclassmembers class * {
    @androidx.compose.runtime.Composable *;
}

# Keep models intact for data parsing
-keep class com.laqta.app.model.** { *; }
